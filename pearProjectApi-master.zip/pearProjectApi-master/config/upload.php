<?php

return [
    'base_path' => 'static/upload/',
    'default' => 'default',
    'editor_img' => 'editor/img',
    'member_avatar' => 'member/avatar',
    'image' => 'image/default',

    'file' => 'file/default',
    'file_temp' => 'file/temp',
];
