<?php
return [
    'notice_push' => true, //是否开启websocket消息推送
];
