let state = {
    loading: false
}

export default state