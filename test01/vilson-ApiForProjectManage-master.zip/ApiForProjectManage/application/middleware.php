<?php
return [
    // 跨域处理
    \app\common\middleware\CORS::class,
];
