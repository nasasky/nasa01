module.exports = {
    TOKEN_KEY: 'LOGIN_TOAKEN'  // 登录token签名的key名称
}