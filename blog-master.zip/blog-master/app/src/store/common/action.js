import { UPDATE_LOADING } from '../actionTypes'

export function updateLoading(data) {
    return { type: UPDATE_LOADING, data }
}