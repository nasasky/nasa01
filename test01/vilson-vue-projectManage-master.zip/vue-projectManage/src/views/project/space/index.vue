<template>
    <div class="project-space-index">
        <wrapper-content>
            555
        </wrapper-content>
    </div>
</template>

<script>
    export default {
        name: "project-space-index"
    }
</script>

<style scoped>

</style>
