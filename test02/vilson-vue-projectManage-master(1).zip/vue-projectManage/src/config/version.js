export default {
    VERSION: '2.5.0',
};
