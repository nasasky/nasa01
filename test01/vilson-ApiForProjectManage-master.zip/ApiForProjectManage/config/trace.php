<?php

return [
    // 内置Html Console 支持扩展
    'type' => 'Html',
];
