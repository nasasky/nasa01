export default {
    crossDomain: false, //是否开启跨域支持
    PROD_URL: 'http://127.0.0.1/pearProjectApi/index.php', //生产环境接口地址
    WS_URI: '',//wss://beta.vilson.xyz:2345 //WebSocket地址
    HOME_PAGE: '/home',//主页路由
};
