<?php

namespace app\common\Model;

class ProjectLog extends CommonModel
{
    protected $pk = 'id';
}
