<?php

namespace app\common\Model;

class ProjectNode extends CommonModel
{
}
