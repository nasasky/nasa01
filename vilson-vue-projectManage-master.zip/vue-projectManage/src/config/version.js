export default {
    VERSION: '2.3.2',
};
