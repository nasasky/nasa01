let state = {
    commentListData: {   // 文章列表数据
        commentList: [],
        pager: {
            currentPage: 0,
            pageCount: 0,
            pageSize: 0,
            total: 0
        }
    },
}

export default state