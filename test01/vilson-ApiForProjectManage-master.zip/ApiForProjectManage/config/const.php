<?php
return [
    'data_key' => 'Mcl5FwCI8cDtnBCQ',
];
