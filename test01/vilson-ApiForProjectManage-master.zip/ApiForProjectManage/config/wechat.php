<?php

return [
    'service_url' => 'https://x.x.com',
    // 下面参数用作微信支付
    'appid'       => '',
    'mch_id'      => '',
    'mch_key'     => '',
];
