<?php
return [
    'task' => [
        'app\\project\\behavior\\Task'
    ],
    'project' => [
        'app\\project\\behavior\\Project'
    ],
];
