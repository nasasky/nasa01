import state from './state'
let initState = state

const user = (state = initState, { type, data }) => {
    switch (type) {
        default:
            return state
    }
}

export default user