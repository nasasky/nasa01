<?php

return [
    'open' => false, //Weather open mail support
    'Host' => 'smtp.example.com',// Specify main and backup SMTP servers
    'SMTPAuth' => true,// Enable SMTP authentication
    'Username' => 'example@example.com',// SMTP username
    'Password' => 'example',// SMTP password
    'SMTPSecure' => 'tls',// Enable TLS encryption, `ssl` also accepted
    'Port' => 25,// TCP port to connect to
];
